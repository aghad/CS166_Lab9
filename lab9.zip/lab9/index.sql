CREATE INDEX priceIndex ON sales(price);
CREATE INDEX stateIndex ON stores(state);
CREATE INDEX nameIndex ON catalog(itemname);
